from flask import Flask, render_template, request
from collections import defaultdict
import ply.lex as lex
import ply.yacc as yacc

app = Flask(__name__)

# Definir palabras reservadas y tokens
reserved = {
    'for': 'RESERVADO',
    'do': 'RESERVADO',
    'while': 'RESERVADO',
    'if': 'RESERVADO',
    'else': 'RESERVADO',
    'public': 'RESERVADO',
    'static': 'RESERVADO',
    'void': 'RESERVADO',
    'int': 'RESERVADO',
    'print': 'RESERVADO',
    'return': 'RESERVADO',
    'break': 'RESERVADO',
    'true': 'RESERVADO',
    'false': 'RESERVADO',
}

tokens = [
    'IDENTIFICADOR', 'NUMERO_ENTERO', 'NUMERO_DECIMAL', 'DELIMITADOR',
    'OPERADOR', 'SIMBOLO', 'RELACIONAL', 'STRING'
] + list(reserved.values())

# Definir tokens
t_ignore = ' \t'
t_DELIMITADOR = r'[(){};]'
t_OPERADOR = r'[=+-/*]'
t_SIMBOLO = r'[.,]'
t_RELACIONAL = r'(<=|>=|==|<|>)'
t_STRING = r'\".*?\"'

# Definir cómo manejar los saltos de línea para actualizar el número de línea
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_NUMERO_DECIMAL(t):
    r'\d+\.\d+'
    t.value = float(t.value)
    return t

def t_NUMERO_ENTERO(t):
    r'\d+'
    t.value = int(t.value)
    return t

def t_IDENTIFICADOR(t):
    r'\w+'
    t.type = reserved.get(t.value, 'IDENTIFICADOR')  # Aquí se asigna el tipo
    return t

def t_error(t):
    print('Caracter no válido', t.value[0])
    t.lexer.skip(1)

lexer = lex.lex()

# Reglas gramaticales para el análisis sintáctico
def p_for_loop(p):
    '''for_loop : RESERVADO '(' initialization ';' condition ';' increment ')' '{' statement_list '}' '''
    print("Sintaxis válida para el bucle 'for'.")

def p_initialization(p):
    '''initialization : RESERVADO IDENTIFICADOR '=' NUMERO_ENTERO'''

def p_condition(p):
    '''condition : IDENTIFICADOR RELACIONAL NUMERO_ENTERO'''

def p_increment(p):
    '''increment : IDENTIFICADOR OPERADOR'''

def p_statement_list(p):
    '''statement_list : statement
                      | statement statement_list'''

def p_statement(p):
    '''statement : IDENTIFICADOR '.' IDENTIFICADOR '(' STRING ')' ';' '''

def p_if_statement(p):
    '''if_statement : RESERVADO '(' condition ')' '{' statement_list '}' '''

def p_error(p):
    print(f"Error de sintaxis en '{p.value}'")

# Construir el parser
parser = yacc.yacc()

@app.route('/', methods=['GET', 'POST'])
def index():
    code = request.form.get('code', '')
    if request.method == 'POST':
        if request.form.get('action') == 'clear':
            code = ''  # Limpiar el código ingresado
        else:
            lexer.lineno = 1  # Reiniciar el número de línea antes de cada análisis
            lexer.input(code)

            result_lexema = []
            token_counts = defaultdict(int)

            for token in lexer:
                token_counts[token.type] += 1
                if token.type == "NUMERO_DECIMAL":
                    entero, decimal = str(token.value).split('.')
                    result_lexema.append(("Número Entero", entero, token.lineno))
                    result_lexema.append(("Símbolo", ".", token.lineno))
                    result_lexema.append(("Número Decimal", decimal, token.lineno))
                    token_counts["NUMERO_ENTERO"] += 1
                    token_counts["SIMBOLO"] += 1
                    token_counts["NUMERO_DECIMAL"] += 1
                else:
                    formatted_type = token.type.replace('_', ' ').title()
                    if formatted_type == "Numero Entero":
                        formatted_type = "Número Entero"
                    elif formatted_type == "Numero Decimal":
                        formatted_type = "Número Decimal"
                    elif formatted_type == "Identificador":
                        formatted_type = "Identificador"
                    result_lexema.append((formatted_type, token.value, token.lineno))
            
            # Formatear los nombres de los tokens para la tabla de resumen
            token_summary = [
                (key.replace('_', ' ').title().replace('Numero', 'Número').replace('Simbolo', 'Símbolo'), count) for key, count in token_counts.items()
            ]
            
            # Intentar el análisis sintáctico
            try:
                parser.parse(code)
                sintaxis_valida = True
            except Exception as e:
                sintaxis_valida = False
                print(f"Error de análisis sintáctico: {str(e)}")
            
            return render_template('index.html', tokens=result_lexema, token_summary=token_summary, code=code, sintaxis_valida=sintaxis_valida)
    
    return render_template('index.html', tokens=None, code=code)

if __name__ == "__main__":
    app.run(debug=True)
