from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

def analizar_lexico(expression):
    tokens = re.findall(r'\d+|\+|\-|\*|\/|\(|\)', expression)
    tipos = []

    for token in tokens:
        if token.isdigit():
            tipos.append((token, "Número entero"))
        elif token in "+-*/":
            operadores = {
                '+': "Operador suma",
                '-': "Operador resta",
                '*': "Operador multiplicación",
                '/': "Operador división"
            }
            tipos.append((token, operadores[token]))
        elif token == '(':
            tipos.append((token, "Paréntesis izquierdo"))
        elif token == ')':
            tipos.append((token, "Paréntesis derecho"))

    return tipos

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=["POST"])
def calculate():
    try:
        expression = request.form['expression']
        tokens = analizar_lexico(expression)
        result = eval(expression)
        return jsonify(result=result, tokens=tokens)
    except Exception as e:
        return jsonify(result=f"Error: {e}", tokens=[])

if __name__ == "__main__":
    app.run(debug=True)
