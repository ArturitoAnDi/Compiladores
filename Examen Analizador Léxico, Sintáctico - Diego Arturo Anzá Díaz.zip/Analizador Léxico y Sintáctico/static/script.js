document.addEventListener('DOMContentLoaded', function() {
    const analizarBtn = document.getElementById('analizarBtn');
    const limpiarBtn = document.getElementById('limpiarBtn');
    const form = document.querySelector('form[action="/"]');
    const textarea = document.querySelector('textarea');

    // Verificar si hay texto en el área de texto para mostrar los dos botones
    form.addEventListener('submit', function(event) {
        if (textarea.value.trim() !== '') {
            analizarBtn.classList.add('mitad');
            limpiarBtn.classList.add('mitad');
            limpiarBtn.classList.remove('oculto');
            analizarBtn.classList.remove('oculto');
        }
    });

    // Evento para limpiar el área de texto y ocultar el botón de limpiar
    limpiarBtn.addEventListener('click', function() {
        textarea.value = '';
        limpiarBtn.classList.add('oculto');
    });
});
